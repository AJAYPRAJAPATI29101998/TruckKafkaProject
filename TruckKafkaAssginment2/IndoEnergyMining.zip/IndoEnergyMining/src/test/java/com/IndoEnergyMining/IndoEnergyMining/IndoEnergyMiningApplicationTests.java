package com.IndoEnergyMining.IndoEnergyMining;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IndoEnergyMiningApplicationTests {

	@Test
	void contextLoads() {
	}

}
